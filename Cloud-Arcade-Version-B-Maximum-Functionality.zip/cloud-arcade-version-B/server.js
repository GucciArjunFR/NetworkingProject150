// Cloud Arcade server — no dependencies, Node 18+ (uses built-in fetch).
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const STARTED = Date.now();

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': TYPES['.json'], 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

// Refuse to probe private/internal addresses (basic SSRF protection).
function isPrivateHost(host) {
  const h = host.toLowerCase();
  return (
    h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.internal') ||
    /^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) ||
    /^169\.254\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h) ||
    h === '0.0.0.0' || h === '[::1]' || h.startsWith('[fc') || h.startsWith('[fd')
  );
}

// Fetches a URL server-side and reports whether its headers forbid being framed.
async function checkEmbed(target) {
  let url;
  try { url = new URL(target); } catch { return { ok: false, error: 'Invalid URL' }; }
  if (!/^https?:$/.test(url.protocol)) return { ok: false, error: 'Only http/https URLs are allowed' };
  if (isPrivateHost(url.hostname)) return { ok: false, error: 'Private/internal addresses are not checked' };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  const t0 = Date.now();
  try {
    const r = await fetch(url, {
      redirect: 'follow',
      signal: controller.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 (CloudArcade embed diagnostics)' },
    });
    const ms = Date.now() - t0;
    try { await r.body?.cancel(); } catch {}

    const xfo = r.headers.get('x-frame-options');
    const csp = r.headers.get('content-security-policy');
    let frameAncestors = null;
    if (csp) {
      const d = csp.split(';').map(s => s.trim()).find(s => s.toLowerCase().startsWith('frame-ancestors'));
      if (d) frameAncestors = d;
    }

    let embeddable = true;
    let reason = 'No frame-blocking headers found. The page may still refuse to work inside a frame (sign-in pages often do).';
    if (xfo && /deny|sameorigin/i.test(xfo)) {
      embeddable = false;
      reason = `Site sends "X-Frame-Options: ${xfo}" — browsers will refuse to show it inside another site.`;
    }
    if (frameAncestors) {
      const value = frameAncestors.slice('frame-ancestors'.length).trim();
      if (value !== '*') {
        embeddable = false;
        reason = `Site sends CSP "${frameAncestors}" — only the listed origins may frame it.`;
      }
    }
    return {
      ok: true, status: r.status, finalUrl: r.url, ms,
      xFrameOptions: xfo, frameAncestors, embeddable, reason,
    };
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'Timed out after 8s' : String(e.message || e) };
  } finally {
    clearTimeout(timer);
  }
}

function environmentName() {
  if (process.env.CODESPACES === 'true') return 'GitHub Codespaces';
  if (process.env.CSB || process.env.CSB_SANDBOX_ID) return 'CodeSandbox';
  if (process.env.REPL_ID) return 'Replit';
  return 'Local machine';
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/') rel = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!filePath.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': TYPES[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const { pathname, searchParams } = new URL(req.url, 'http://localhost');
  const t0 = Date.now();
  res.on('finish', () => {
    if (pathname.startsWith('/api/') && pathname !== '/api/ping') {
      console.log(`${new Date().toISOString()} ${req.method} ${req.url} ${res.statusCode} ${Date.now() - t0}ms`);
    }
  });

  if (pathname === '/api/health') {
    return sendJson(res, 200, {
      ok: true,
      node: process.version,
      environment: environmentName(),
      codespace: process.env.CODESPACE_NAME || null,
      uptimeSeconds: Math.round((Date.now() - STARTED) / 1000),
      serverTime: new Date().toISOString(),
    });
  }
  if (pathname === '/api/ping') return sendJson(res, 200, { t: Date.now() });
  if (pathname === '/api/check') {
    const target = searchParams.get('url');
    if (!target) return sendJson(res, 400, { ok: false, error: 'Missing ?url=' });
    return sendJson(res, 200, await checkEmbed(target));
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  serveStatic(req, res, pathname);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Cloud Arcade running on http://localhost:${PORT}  (${environmentName()})`);
  if (process.env.CODESPACES === 'true') {
    console.log('Codespaces: open the PORTS tab and click the globe icon next to port 3000.');
    console.log(`To let your teacher open it, make the port public:  gh codespace ports visibility ${PORT}:public -c $CODESPACE_NAME`);
  }
});
