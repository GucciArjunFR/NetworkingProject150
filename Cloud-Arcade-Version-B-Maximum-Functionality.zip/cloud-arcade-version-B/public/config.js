window.CLOUD_ARCADE_CONFIG = { edition: 'B' };
