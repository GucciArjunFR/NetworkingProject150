// Cloud Arcade front end.
(() => {
  const EDITION = (window.CLOUD_ARCADE_CONFIG || {}).edition || 'A';
  const $ = id => document.getElementById(id);

  // ---------------- Event log ----------------
  const events = [];
  function log(msg, level = 'info') {
    const entry = { time: new Date().toISOString(), level, msg };
    events.push(entry);
    const li = document.createElement('li');
    li.className = level;
    li.innerHTML = `<span class="t">${entry.time.slice(11, 19)}</span> `;
    li.append(document.createTextNode(msg));
    $('log').prepend(li);
    (level === 'error' ? console.error : console.log)('[CloudArcade]', msg);
  }
  window.addEventListener('error', e => log(`Script error: ${e.message}`, 'error'));
  $('logClear').onclick = () => { events.length = 0; $('log').innerHTML = ''; };
  $('logExport').onclick = () => {
    const blob = new Blob([JSON.stringify({ edition: EDITION, userAgent: navigator.userAgent, events }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `cloud-arcade-log-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  $('edition').textContent = EDITION === 'B' ? 'Version B' : 'Version A';
  log(`Cloud Arcade ${EDITION === 'B' ? 'Version B (maximum functionality)' : 'Version A (strict embedded)'} loaded`);

  // ---------------- Navigation ----------------
  let activeGame = null, gameName = 'snake';
  function show(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === `view-${view}`));
    document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    if (view === 'games') startGame(gameName); else stopGame();
    if (view === 'diag') refreshServer();
    history.replaceState(null, '', `#${view}`);
  }
  document.querySelectorAll('#nav button').forEach(b => b.onclick = () => show(b.dataset.view));
  document.querySelectorAll('[data-go]').forEach(c => c.onclick = () => show(c.dataset.go));

  // ---------------- Games ----------------
  function startGame(name) {
    stopGame();
    gameName = name;
    document.querySelectorAll('[data-game]').forEach(b => b.classList.toggle('active', b.dataset.game === name));
    activeGame = Games[name]($('gameCanvas'), t => $('gameStatus').textContent = t, m => log(m));
    $('gameHelp').textContent = activeGame.help;
    $('gameCanvas').focus();
  }
  function stopGame() { if (activeGame) { activeGame.stop(); activeGame = null; } }
  document.querySelectorAll('[data-game]').forEach(b => b.onclick = () => startGame(b.dataset.game));
  $('gameRestart').onclick = () => { activeGame && activeGame.restart(); $('gameCanvas').focus(); };

  // ---------------- Server & embed checks ----------------
  async function refreshServer() {
    try {
      const r = await fetch('/api/health');
      const h = await r.json();
      $('serverStatus').textContent = `Server online · ${h.environment}`;
      $('serverStatus').className = 'server-status ok';
      $('serverTable').innerHTML = [
        ['Environment', h.environment], ['Codespace', h.codespace || '—'], ['Node.js', h.node],
        ['Uptime', `${h.uptimeSeconds}s`], ['Page origin', location.origin],
        ['Secure context (HTTPS)', window.isSecureContext ? 'Yes' : 'No'],
      ].map(([k, v]) => `<tr><td>${k}</td><td>${escapeHtml(String(v))}</td></tr>`).join('');
      return h;
    } catch (e) {
      $('serverStatus').textContent = 'Server unreachable';
      $('serverStatus').className = 'server-status down';
      log(`Health check failed: ${e.message}`, 'error');
    }
  }
  function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  async function checkHeaders(url) {
    const r = await fetch(`/api/check?url=${encodeURIComponent(url)}`);
    return r.json();
  }

  function setResult(el, text, kind) { el.textContent = text; el.className = `result ${kind || ''}`; }

  // Loads a URL in an iframe and runs the server-side header check in parallel.
  async function embed({ url, frame, result, label }) {
    log(`${label}: testing ${url}`);
    setResult(result, `Checking ${url} …`, 'warn');
    const t0 = performance.now();
    frame.onload = () => log(`${label}: iframe load event after ${Math.round(performance.now() - t0)} ms`);
    frame.src = url;
    try {
      const c = await checkHeaders(url);
      if (!c.ok) {
        setResult(result, `Could not analyse headers: ${c.error}\nThe frame below may still load; look at it to confirm.`, 'warn');
        log(`${label}: header check failed (${c.error})`, 'warn');
        return c;
      }
      const lines = [
        c.embeddable ? '✅ Embedding allowed by headers' : '⛔ Embedding blocked by the site',
        c.reason,
        `HTTP ${c.status} · ${c.ms} ms · ${c.finalUrl}`,
        `X-Frame-Options: ${c.xFrameOptions || '(none)'}`,
        `CSP frame-ancestors: ${c.frameAncestors || '(none)'}`,
      ];
      setResult(result, lines.join('\n'), c.embeddable ? 'good' : 'bad');
      log(`${label}: ${c.embeddable ? 'embeddable' : 'BLOCKED'} — ${c.reason}`, c.embeddable ? 'info' : 'warn');
      return c;
    } catch (e) {
      setResult(result, `Header check error: ${e.message}`, 'bad');
      log(`${label}: ${e.message}`, 'error');
    }
  }

  // ---------------- YouTube ----------------
  function youtubeId(input) {
    const s = input.trim();
    if (/^[\w-]{11}$/.test(s)) return s;
    try {
      const u = new URL(s);
      if (u.hostname === 'youtu.be') return u.pathname.slice(1, 12);
      if (u.searchParams.get('v')) return u.searchParams.get('v');
      const m = u.pathname.match(/\/(embed|shorts|live)\/([\w-]{11})/);
      if (m) return m[2];
    } catch {}
    return null;
  }
  $('ytLoad').onclick = () => {
    const id = youtubeId($('ytInput').value);
    if (!id) return setResult($('ytResult'), 'That does not look like a YouTube link or video ID.', 'bad');
    $('ytFrame').src = `https://www.youtube-nocookie.com/embed/${id}?rel=0`;
    setResult($('ytResult'), `Playing video ${id} through YouTube's official embedded player.`, 'good');
    log(`YouTube: loaded video ${id}`);
  };

  // ---------------- CodeSandbox ----------------
  function codesandboxEmbed(input) {
    try {
      const u = new URL(input.trim());
      if (!/codesandbox\.io$/.test(u.hostname) && !u.hostname.endsWith('.csb.app')) return null;
      if (u.hostname.endsWith('.csb.app')) return u.href; // running preview URL
      let m = u.pathname.match(/^\/(?:s|embed)\/([^/?#]+)/);
      if (m) return `https://codesandbox.io/embed/${m[1]}?view=split&fontsize=14`;
      if (u.pathname.startsWith('/p/')) return `https://codesandbox.io${u.pathname}?embed=1`;
    } catch {}
    return null;
  }
  $('csbLoad').onclick = () => {
    const url = codesandboxEmbed($('csbInput').value);
    if (!url) return setResult($('csbResult'), 'Paste a codesandbox.io sandbox link (it must be public).', 'bad');
    embed({ url, frame: $('csbFrame'), result: $('csbResult'), label: 'CodeSandbox' });
  };

  // ---------------- Replit ----------------
  function replitUrl(input) {
    try {
      const u = new URL(input.trim());
      if (!/(^|\.)replit\.(com|app|dev)$/.test(u.hostname)) return null;
      return u;
    } catch { return null; }
  }
  $('replLoad').onclick = () => {
    const u = replitUrl($('replInput').value);
    if (!u) return setResult($('replResult'), 'Paste a replit.com link.', 'bad');
    if (u.hostname === 'replit.com') u.searchParams.set('embed', 'true');
    embed({ url: u.href, frame: $('replFrame'), result: $('replResult'), label: 'Replit' });
  };
  $('replOpen').onclick = () => {
    const u = replitUrl($('replInput').value);
    if (!u) return setResult($('replResult'), 'Paste a replit.com link first.', 'bad');
    window.open(u.href, '_blank', 'noopener');
    log(`Replit: opened ${u.href} in a new tab`);
  };

  // ---------------- Web viewer ----------------
  $('webLoad').onclick = () => {
    let url = $('webInput').value.trim();
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    embed({ url, frame: $('webFrame'), result: $('webResult'), label: 'Web Viewer' });
  };

  // ---------------- GeForce NOW ----------------
  $('gfnTest').onclick = async () => {
    const url = $('gfnUrl').value.trim();
    const c = await embed({ url, frame: $('gfnFrame'), result: $('gfnResult'), label: 'GeForce NOW' });
    if (c && c.ok && !c.embeddable) {
      $('gfnResult').textContent += EDITION === 'B'
        ? '\n\nNVIDIA does not allow its player inside other sites. Use "Launch" above to play.'
        : '\n\nNVIDIA does not allow its player inside other sites. That restriction is set by NVIDIA; this app cannot override it.';
    }
  };

  function browserInfo() {
    const ua = navigator.userAgent;
    const brands = (navigator.userAgentData && navigator.userAgentData.brands || []).map(b => b.brand).join(', ');
    let name = 'Unknown';
    if (/Edg\//.test(ua)) name = 'Microsoft Edge';
    else if (/CrOS/.test(ua)) name = 'Chrome on ChromeOS';
    else if (/Chrome\//.test(ua)) name = 'Google Chrome / Chromium';
    else if (/Firefox\//.test(ua)) name = 'Firefox';
    else if (/Safari\//.test(ua)) name = 'Safari';
    return { name, brands, chromium: /Chrome\/|Edg\//.test(ua) };
  }

  $('gfnCaps').onclick = () => {
    const b = browserInfo();
    const c = navigator.connection || {};
    const rows = [
      ['Browser', b.name, b.chromium ? 'yes' : 'maybe', b.chromium ? 'Chromium-based browsers are the main supported option' : 'Check NVIDIA\'s supported-browser list'],
      ['WebRTC (real-time streaming)', 'RTCPeerConnection' in window],
      ['Hardware video decode API (WebCodecs)', 'VideoDecoder' in window],
      ['Gamepad API', 'getGamepads' in navigator],
      ['Pointer Lock (mouse capture)', 'requestPointerLock' in Element.prototype],
      ['Fullscreen', 'requestFullscreen' in Element.prototype],
      ['Keyboard Lock', !!(navigator.keyboard && navigator.keyboard.lock)],
      ['Secure context (HTTPS)', window.isSecureContext],
      ['Browser bandwidth estimate', c.downlink ? `${c.downlink} Mbps` : 'unavailable', c.downlink ? (c.downlink >= 15 ? 'yes' : 'maybe') : 'maybe'],
      ['Browser RTT estimate', c.rtt != null ? `${c.rtt} ms` : 'unavailable', c.rtt != null ? (c.rtt <= 80 ? 'yes' : 'maybe') : 'maybe'],
    ];
    $('gfnCapsTable').innerHTML = rows.map(([k, v, cls, note]) => {
      let text = v, klass = cls;
      if (typeof v === 'boolean') { text = v ? 'Supported' : 'Missing'; klass = v ? 'yes' : 'no'; }
      return `<tr><td>${k}${note ? `<div class="muted">${note}</div>` : ''}</td><td class="${klass}">${escapeHtml(String(text))}</td></tr>`;
    }).join('');
    log(`Readiness check: ${b.name}, WebRTC=${'RTCPeerConnection' in window}, downlink=${c.downlink || 'n/a'}`);
  };

  if (EDITION === 'B') {
    const GFN = 'https://play.geforcenow.com/';
    const launchTab = $('gfnLaunchTab'), launchWin = $('gfnLaunchWindow');
    if (launchTab) launchTab.onclick = () => {
      window.open(GFN, '_blank', 'noopener');
      log('GeForce NOW: launched official player in a new tab');
    };
    if (launchWin) launchWin.onclick = () => {
      const w = Math.min(screen.availWidth, 1600), h = Math.min(screen.availHeight, 900);
      window.open(GFN, 'cloudArcadeGFN', `popup,noopener,width=${w},height=${h},left=0,top=0`);
      log('GeForce NOW: launched official player in a game window');
    };
  }

  // ---------------- Latency ----------------
  $('pingBtn').onclick = async () => {
    const times = [];
    setResult($('pingResult'), 'Pinging…', 'warn');
    for (let i = 0; i < 10; i++) {
      const t0 = performance.now();
      try { await fetch(`/api/ping?i=${i}`, { cache: 'no-store' }); times.push(performance.now() - t0); } catch {}
    }
    if (!times.length) return setResult($('pingResult'), 'All pings failed.', 'bad');
    times.sort((a, b) => a - b);
    const med = times[Math.floor(times.length / 2)], min = times[0], max = times[times.length - 1];
    const jitter = max - min;
    setResult($('pingResult'),
      `Median ${med.toFixed(0)} ms · min ${min.toFixed(0)} · max ${max.toFixed(0)} · spread ${jitter.toFixed(0)} ms (${times.length}/10 ok)`,
      med < 80 ? 'good' : med < 150 ? 'warn' : 'bad');
    log(`Ping to app server: median ${med.toFixed(0)} ms`);
  };

  // ---------------- Start ----------------
  refreshServer();
  setInterval(refreshServer, 30000);
  const initial = location.hash.slice(1);
  show(document.getElementById(`view-${initial}`) ? initial : 'home');
})();
