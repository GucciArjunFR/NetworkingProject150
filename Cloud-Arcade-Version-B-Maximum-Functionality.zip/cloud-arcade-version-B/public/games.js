// Original Canvas games: Snake and Breakout.
const Games = (() => {
  const getHi = k => { try { return Number(localStorage.getItem(k)) || 0; } catch { return 0; } };
  const setHi = (k, v) => { try { localStorage.setItem(k, String(v)); } catch {} };
  const typing = e => /INPUT|TEXTAREA/.test(e.target.tagName);

  function overlay(ctx, W, H, title, sub) {
    ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
    ctx.font = 'bold 36px system-ui'; ctx.fillText(title, W / 2, H / 2 - 8);
    if (sub) { ctx.font = '18px system-ui'; ctx.fillStyle = '#aaa'; ctx.fillText(sub, W / 2, H / 2 + 26); }
  }

  // ---------------- SNAKE ----------------
  function snake(canvas, status, onEvent) {
    canvas.width = 600; canvas.height = 600;
    const ctx = canvas.getContext('2d'), N = 20, S = canvas.width / N;
    let body, dir, next, food, score, over, paused, started, speed, timer;

    function place() {
      do { food = { x: Math.floor(Math.random() * N), y: Math.floor(Math.random() * N) }; }
      while (body.some(p => p.x === food.x && p.y === food.y));
    }
    function updateStatus() { status(`Score ${score} · Best ${getHi('snakeHi')}`); }
    function reset() {
      body = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
      dir = { x: 1, y: 0 }; next = dir; score = 0; over = false; paused = false; started = false; speed = 120;
      place(); updateStatus(); restartTimer(); draw();
    }
    function restartTimer() { clearInterval(timer); timer = setInterval(step, speed); }
    function step() {
      if (over || paused || !started) return;
      dir = next;
      const h = { x: body[0].x + dir.x, y: body[0].y + dir.y };
      if (h.x < 0 || h.y < 0 || h.x >= N || h.y >= N || body.some(p => p.x === h.x && p.y === h.y)) {
        over = true;
        if (score > getHi('snakeHi')) setHi('snakeHi', score);
        onEvent(`Snake game over — score ${score}`);
        updateStatus(); draw(); return;
      }
      body.unshift(h);
      if (h.x === food.x && h.y === food.y) {
        score += 10; place(); updateStatus();
        if (speed > 60) { speed -= 3; restartTimer(); }
      } else body.pop();
      draw();
    }
    function draw() {
      ctx.fillStyle = '#05080c'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#0f1620';
      for (let i = 0; i <= N; i++) {
        ctx.beginPath(); ctx.moveTo(i * S, 0); ctx.lineTo(i * S, canvas.height); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i * S); ctx.lineTo(canvas.width, i * S); ctx.stroke();
      }
      ctx.fillStyle = '#f85149';
      ctx.beginPath(); ctx.arc(food.x * S + S / 2, food.y * S + S / 2, S / 2.6, 0, Math.PI * 2); ctx.fill();
      body.forEach((p, i) => {
        ctx.fillStyle = i === 0 ? '#9be22d' : '#76b900';
        ctx.fillRect(p.x * S + 2, p.y * S + 2, S - 4, S - 4);
      });
      if (!started) overlay(ctx, canvas.width, canvas.height, 'SNAKE', 'Press an arrow key or WASD to start');
      else if (over) overlay(ctx, canvas.width, canvas.height, 'Game over', 'Press R to restart');
      else if (paused) overlay(ctx, canvas.width, canvas.height, 'Paused', 'Press P or Space');
    }
    const dirs = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0], w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0] };
    function key(e) {
      if (typing(e)) return;
      const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      if (dirs[k]) {
        e.preventDefault();
        const [x, y] = dirs[k];
        if (!(x === -dir.x && y === -dir.y)) next = { x, y };
        if (!started && !over) { started = true; onEvent('Snake started'); }
      } else if (k === 'r') reset();
      else if ((k === 'p' || k === ' ') && started && !over) { e.preventDefault(); paused = !paused; draw(); }
    }
    window.addEventListener('keydown', key);
    reset();
    return {
      help: 'Arrow keys / WASD to move · P or Space to pause · R to restart. The snake speeds up as it grows.',
      restart: reset,
      stop() { clearInterval(timer); window.removeEventListener('keydown', key); },
    };
  }

  // ---------------- BREAKOUT ----------------
  function breakout(canvas, status, onEvent) {
    canvas.width = 600; canvas.height = 600;
    const ctx = canvas.getContext('2d'), W = canvas.width, H = canvas.height;
    const ROWS = 6, COLS = 10, GAP = 6, BH = 18, BW = (W - 20 - GAP * (COLS - 1)) / COLS;
    const COLORS = ['#f85149', '#f0883e', '#d29922', '#76b900', '#58a6ff', '#bc8cff'];
    let paddle, ball, bricks, score, lives, level, state, raf, keys = { l: false, r: false };

    function build() {
      bricks = [];
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++)
        bricks.push({ x: 10 + c * (BW + GAP), y: 60 + r * (BH + GAP), w: BW, h: BH, row: r, alive: true });
    }
    function serve() {
      const sp = 4.2 + level * 0.5;
      ball = { x: W / 2, y: H - 50, r: 7, dx: sp * 0.6 * (Math.random() < 0.5 ? -1 : 1), dy: -sp * 0.8 };
      state = 'ready';
    }
    function updateStatus() { status(`Score ${score} · Lives ${lives} · Level ${level} · Best ${getHi('breakoutHi')}`); }
    function reset() {
      paddle = { x: W / 2 - 55, y: H - 30, w: 110, h: 12 };
      score = 0; lives = 3; level = 1; build(); serve(); updateStatus();
    }
    function launch() {
      if (state === 'ready') { state = 'play'; onEvent('Breakout ball launched'); }
      else if (state === 'over') reset();
      else if (state === 'won') { level++; build(); serve(); updateStatus(); }
    }
    function update() {
      if (keys.l) paddle.x -= 8;
      if (keys.r) paddle.x += 8;
      paddle.x = Math.max(0, Math.min(W - paddle.w, paddle.x));
      if (state === 'ready') { ball.x = paddle.x + paddle.w / 2; ball.y = paddle.y - ball.r - 1; return; }
      if (state !== 'play') return;

      const px = ball.x, py = ball.y;
      ball.x += ball.dx; ball.y += ball.dy;
      if (ball.x < ball.r) { ball.x = ball.r; ball.dx = Math.abs(ball.dx); }
      if (ball.x > W - ball.r) { ball.x = W - ball.r; ball.dx = -Math.abs(ball.dx); }
      if (ball.y < ball.r) { ball.y = ball.r; ball.dy = Math.abs(ball.dy); }

      // Paddle: bounce angle depends on where the ball hits.
      if (ball.dy > 0 && ball.y + ball.r >= paddle.y && py + ball.r <= paddle.y + 6 &&
          ball.x >= paddle.x - ball.r && ball.x <= paddle.x + paddle.w + ball.r) {
        const hit = Math.max(-1, Math.min(1, (ball.x - (paddle.x + paddle.w / 2)) / (paddle.w / 2)));
        const sp = Math.min(Math.hypot(ball.dx, ball.dy) * 1.02, 10);
        const ang = hit * 1.05; // max ~60°
        ball.dx = sp * Math.sin(ang); ball.dy = -Math.abs(sp * Math.cos(ang));
        ball.y = paddle.y - ball.r;
      }

      for (const b of bricks) {
        if (!b.alive) continue;
        const cx = Math.max(b.x, Math.min(ball.x, b.x + b.w));
        const cy = Math.max(b.y, Math.min(ball.y, b.y + b.h));
        if ((ball.x - cx) ** 2 + (ball.y - cy) ** 2 <= ball.r ** 2) {
          b.alive = false;
          score += 10 * (ROWS - b.row);
          const fromSide = py + ball.r > b.y && py - ball.r < b.y + b.h;
          if (fromSide) ball.dx = -ball.dx; else ball.dy = -ball.dy;
          if (score > getHi('breakoutHi')) setHi('breakoutHi', score);
          updateStatus();
          break;
        }
      }
      if (bricks.every(b => !b.alive)) { state = 'won'; onEvent(`Breakout level ${level} cleared`); }
      if (ball.y > H + ball.r) {
        lives--; updateStatus();
        if (lives <= 0) { state = 'over'; onEvent(`Breakout game over — score ${score}`); }
        else serve();
      }
    }
    function draw() {
      ctx.fillStyle = '#05080c'; ctx.fillRect(0, 0, W, H);
      for (const b of bricks) if (b.alive) {
        ctx.fillStyle = COLORS[b.row % COLORS.length];
        ctx.fillRect(b.x, b.y, b.w, b.h);
      }
      ctx.fillStyle = '#e6edf3'; ctx.fillRect(paddle.x, paddle.y, paddle.w, paddle.h);
      ctx.beginPath(); ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
      if (state === 'ready') overlay(ctx, W, H, `Level ${level}`, 'Click or press Space to launch');
      if (state === 'over') overlay(ctx, W, H, 'Game over', 'Click or press Space to play again');
      if (state === 'won') overlay(ctx, W, H, 'Level cleared!', 'Click or press Space for the next level');
    }
    function loop() { update(); draw(); raf = requestAnimationFrame(loop); }
    function keydown(e) {
      if (typing(e)) return;
      if (e.key === 'ArrowLeft' || e.key === 'a') { keys.l = true; e.preventDefault(); }
      if (e.key === 'ArrowRight' || e.key === 'd') { keys.r = true; e.preventDefault(); }
      if (e.key === ' ') { e.preventDefault(); launch(); }
    }
    function keyup(e) {
      if (e.key === 'ArrowLeft' || e.key === 'a') keys.l = false;
      if (e.key === 'ArrowRight' || e.key === 'd') keys.r = false;
    }
    function mouse(e) {
      const rect = canvas.getBoundingClientRect();
      paddle.x = (e.clientX - rect.left) * (W / rect.width) - paddle.w / 2;
    }
    window.addEventListener('keydown', keydown);
    window.addEventListener('keyup', keyup);
    canvas.addEventListener('mousemove', mouse);
    canvas.addEventListener('click', launch);
    reset(); loop();
    return {
      help: 'Mouse or ←/→ to move the paddle · Click or Space to launch. Where the ball hits the paddle controls its angle. Higher bricks are worth more.',
      restart: reset,
      stop() {
        cancelAnimationFrame(raf);
        window.removeEventListener('keydown', keydown);
        window.removeEventListener('keyup', keyup);
        canvas.removeEventListener('mousemove', mouse);
        canvas.removeEventListener('click', launch);
      },
    };
  }

  return { snake, breakout };
})();
