# Cloud Arcade — Version B — Maximum functionality

A cloud-hosted entertainment hub built with Node.js and vanilla JavaScript (no dependencies):

- **Arcade Games**: Snake and Breakout, written from scratch on HTML5 Canvas, with high scores, levels and speed-up.
- **GeForce NOW**: embed test, a server-side header analysis that shows *why* NVIDIA's player can or can't be framed, and a cloud-gaming readiness check (WebRTC, WebCodecs, Gamepad, Pointer Lock, bandwidth/RTT).
- **GeForce NOW launch** (Version B): opens NVIDIA's official player in a new tab or a sized game window so you can sign in and play.
- **YouTube**: the official embedded player; paste any video link.
- **CodeSandbox**: converts any public sandbox link to CodeSandbox's embed URL.
- **Replit**: embed test plus direct launch.
- **Web Viewer**: loads sites that allow framing and explains blocks for the rest.
- **Diagnostics**: server health, latency to the app server, and an exportable event log.

## Run it

### GitHub Codespaces
1. Create an empty GitHub repository and open it in a Codespace (**Code → Codespaces → Create codespace**).
2. Drag `Cloud-Arcade-Version-B-Maximum-Functionality.zip` into the Codespace file explorer.
3. In the terminal:
```bash
unzip Cloud-Arcade-Version-B-Maximum-Functionality.zip
cd cloud-arcade-version-B
npm start
```
4. Open the **PORTS** tab and click the globe icon next to port **3000**.
5. **So your teacher can open it from their own computer**, make the port public (open a second terminal):
```bash
gh codespace ports visibility 3000:public -c $CODESPACE_NAME
```
   (Or right-click port 3000 → **Port Visibility → Public**.) Private ports only work for you.

### CodeSandbox
1. Create a new **Devbox** → **Node.js** template (or import a GitHub repo containing this folder).
2. Upload the zip, then in the terminal:
```bash
unzip Cloud-Arcade-Version-B-Maximum-Functionality.zip
cd cloud-arcade-version-B
npm start
```
3. Open the preview for port 3000. If you put the project files at the repo root, `.codesandbox/tasks.json` starts it automatically.

### Any computer with Node.js 18+
```bash
unzip Cloud-Arcade-Version-B-Maximum-Functionality.zip
cd cloud-arcade-version-B
npm start
```
Then open http://localhost:3000

No `npm install` is needed; there are no dependencies.

## About GeForce NOW
GeForce NOW is a commercial streaming service. NVIDIA decides whether its player may run inside other sites, and the **Embed test** shows the exact header NVIDIA sends. If it reports *blocked*, the browser will refuse to show the player inside this app, and no client-side code can legitimately change that.

**Version B** adds **Launch in new tab** and **Launch in game window**. Both open NVIDIA's official player at `play.geforcenow.com`, where you sign in with your NVIDIA account directly (this app never handles your password) and start a game. Gameplay runs in NVIDIA's window, not inside this app's page.

Demo checklist:
1. Open the app → **GeForce NOW** → **Check this browser** (all green is ideal).
2. **Run embed test** → shows whether NVIDIA allows framing and why.
3. **Launch in game window** → sign in on NVIDIA's page → pick a game.
   - Free-to-play titles still need that game's own account linked (for example an Epic account for Fortnite).
   - Free-tier members may wait in a queue.
4. Back in the app → **Diagnostics** shows each step in the event log.

Cloud gaming needs a strong connection. NVIDIA publishes minimum bandwidth and latency requirements on its system-requirements page. School networks often block or throttle streaming services.

## Project structure
```
server.js            Node HTTP server + /api/health, /api/ping, /api/check (embed header analysis)
public/index.html    App shell and all views
public/app.js        Navigation, embeds, GeForce NOW tools, diagnostics, event log
public/games.js      Snake and Breakout
public/config.js     Edition flag (B)
.devcontainer/       Codespaces config (Node 20, forwards port 3000)
.codesandbox/        CodeSandbox Devbox start task
```

## Troubleshooting
- `EADDRINUSE`: the server is already running. Press Ctrl+C in the other terminal, or run `PORT=3001 npm start`.
- Teacher sees a GitHub sign-in page or 404: the port is still private (see step 5).
- `fetch is not defined`: Node is older than 18. Run `node -v`; Codespaces ships Node 20.
- Embedded site shows a blank/grey box: open Diagnostics or the result box; the site is almost certainly sending `X-Frame-Options` or `frame-ancestors`.
